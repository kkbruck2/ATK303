/****Responsive Vertical Timeline ****/

/* used tutorial as reference (to relink) */

/* Key Lessons */
/* :nth-child() selector 
/* Relative positionign center, use margin: 0 auto; Positive positioning center, use left:50%, top:50%, transform: translate(-50%, -50%); */
/* call elements by hierarchy instead of just by class name */ 

/* unresolved: aligning the numbers */